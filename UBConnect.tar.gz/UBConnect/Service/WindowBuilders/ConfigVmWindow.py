import gi
import subprocess

import virtualbox as virtualbox

from Service.WindowBuilders import MainWindowEventHandler

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk


class ConfigVmWindow:
    def __init__(self, vm):
        self.vmthis = vm
        self.builder = Gtk.Builder()
        self.builder.add_from_file("res/Ar.glade")
        self.second_win = self.builder.get_object("configvm")
        self.usb_tv = self.builder.get_object("cvm_usb_tv")
        self.folders_tv = self.builder.get_object("cvm_tv_sharedfolders")

        self.builder.connect_signals(EventHandler(self))
        self.fill_tv_usb()
        self.fill_tv_folders()
        self.second_win.show()
        print(self.vmthis)

    def fill_tv_usb(self):
        list_usb = Gtk.ListStore(bool, str)
        i = 0
        while i < len(self.vmthis.usb_device_filters.device_filters):
            list_usb.append([i + 1, self.vmthis.usb_device_filters.device_filters[i].name])
            i += 1

        text_renderer = Gtk.CellRendererText()
        bool_renderer = Gtk.CellRendererToggle()

        ccol1 = Gtk.TreeViewColumn(title="Активно", cell_renderer=bool_renderer, text=0)
        ccol2 = Gtk.TreeViewColumn(title="Устройство", cell_renderer=text_renderer, text=1)

        self.usb_tv.append_column(ccol1)
        self.usb_tv.append_column(ccol2)
        self.usb_tv.set_model(list_usb)

    def fill_tv_folders(self):
        list_fold = Gtk.ListStore(str, str, bool, bool, str)
        i = 0
        while i < len(self.vmthis.shared_folders):
            list_fold.append([self.vmthis.shared_folders[i].name, self.vmthis.shared_folders[i].host_path,
                              self.vmthis.shared_folders[i].accessible, self.vmthis.shared_folders[i].auto_mount,
                              self.vmthis.shared_folders[i].auto_mount_point])
            i += 1

        text_renderer = Gtk.CellRendererText()
        bool_renderer = Gtk.CellRendererToggle()

        col1 = Gtk.TreeViewColumn(title="Имя", cell_renderer=text_renderer, text=0)
        col2 = Gtk.TreeViewColumn(title="Путь", cell_renderer=text_renderer, text=1)
        col3 = Gtk.TreeViewColumn(title="Доступ", cell_renderer=bool_renderer, text=2)
        col4 = Gtk.TreeViewColumn(title="Авто-монтирование", cell_renderer=bool_renderer, text=3)
        col5 = Gtk.TreeViewColumn(title="Точка монтирования", cell_renderer=text_renderer, text=4)

        self.folders_tv.append_column(col1)
        self.folders_tv.append_column(col2)
        self.folders_tv.append_column(col3)
        self.folders_tv.append_column(col4)
        self.folders_tv.append_column(col5)
        self.folders_tv.set_model(list_fold)

class EventHandler:

    def __init__(self, context):
        self.context = context

    def close_cfg_vm(self, test):
        self.context.second_win.destroy()


if __name__ == '__main__':
    main = ConfigVmWindow()
    Gtk.main()
