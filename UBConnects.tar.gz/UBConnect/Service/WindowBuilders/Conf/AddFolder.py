import subprocess
import tkinter
from tkinter import filedialog

import gi


gi.require_version('Gtk', '3.0')
from gi.repository import Gtk


class AddFolder:
    def __init__(self, cvw):
        self.conf = cvw
        self.builder = Gtk.Builder()
        self.builder.add_from_file("res/Ar.glade")
        self.Add_fold_win = self.builder.get_object("addfolder")
        self.builder.connect_signals(EventHandler(self))
        self.Path = self.builder.get_object("addfolder_entry_path")
        self.Folder = self.builder.get_object("addfolder_entry_folder")
        self.Ro = self.builder.get_object("addfolder_cb_ro")
        self.Automount = self.builder.get_object("addfolder_cb_automount")
        self.Mount_point = self.builder.get_object("addfolder_entry_mount_point")

        self.Add_fold_win.show()

class EventHandler:

    def __init__(self, context):
        self.context = context

    def addfolder_btn_cancel_clicked_cb(self, test):
        self.context.Add_fold_win.destroy()

    def addfolder_btn_show_clicked_cb(self, test):
        root = tkinter.Tk()
        root.withdraw()
        self.context.path = filedialog.askdirectory(parent=root, initialdir="/", title='Please select a directory')
        self.context.Path.set_text(self.context.path)
        self.context.folder = self.context.path.split('/')
        self.context.Folder.set_text(self.context.folder[len(self.context.folder) - 1])

    def addfolder_btn_add_clicked_cb(self, test):

        self.path = self.context.Path.get_text()
        self.name = self.context.Folder.get_text()
        self.readonly = self.context.Ro.get_active()
        self.automount = self.context.Automount.get_active()
        self.automount_p = self.context.Mount_point.get_text()

        print(self.path)
        print(self.name)
        print(self.readonly)
        print(self.automount)
        print(self.automount_p)





if __name__ == '__main__':
    main = AddFolder()
    Gtk.main()
